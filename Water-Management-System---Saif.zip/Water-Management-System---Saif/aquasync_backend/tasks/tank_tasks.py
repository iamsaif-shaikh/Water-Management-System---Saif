import logging
import random
from decimal import Decimal
from celery import shared_task
from django.db import transaction
from django.utils import timezone
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

logger = logging.getLogger(__name__)


def _simulate_reading(tank, motor_state):
    """
    Simulate sensor data with slight random drift.
    In production, replace this with actual IoT sensor reads.
    """
    # Get last reading if exists
    last = tank.readings.order_by('-timestamp').first()

    if last:
        base_pct = float(last.water_level_pct)
    else:
        # Initialize at 60% if no reading exists
        base_pct = 60.0

    # Simulate fill/drain based on motor state
    if motor_state.motor_on:
        # Motor is filling (0.5–1.5 LPM inflow, reading every 30s)
        # 30s of fill at ~40 LPM = ~1200L per 30s cycle → ~ 8% per cycle for 15000L tank
        delta = random.uniform(0.3, 1.2)  # % per 30s
    else:
        # Normal consumption / evaporation
        delta = -random.uniform(0.05, 0.3)  # % per 30s

    new_pct = round(max(0.0, min(100.0, base_pct + delta)), 2)

    # Simulate temperature drift (22–32°C)
    if last:
        base_temp = float(last.temperature_celsius)
    else:
        base_temp = 26.0
    new_temp = round(max(22.0, min(32.0, base_temp + random.uniform(-0.5, 0.5))), 2)

    # Purity index: mostly Excellent/Good, occasional Fair/Poor
    purity_weights = [50, 35, 10, 5]  # Excellent, Good, Fair, Poor
    purity_index = random.choices([0, 1, 2, 3], weights=purity_weights, k=1)[0]

    # Flow rate: 0 if motor off, 30-50 LPM if motor on
    flow_rate = round(random.uniform(30.0, 50.0), 2) if motor_state.motor_on else 0.0

    return {
        'water_level_pct': Decimal(str(new_pct)),
        'purity_index': purity_index,
        'temperature_celsius': Decimal(str(new_temp)),
        'flow_rate_lpm': Decimal(str(flow_rate)),
        'motor_on': motor_state.motor_on,
    }


@shared_task(name='tasks.tank_tasks.record_tank_readings', bind=True, max_retries=3)
def record_tank_readings(self):
    """Record sensor readings for all tanks every 30 seconds."""
    from apps.tanks.models import Tank, TankReading, MotorState

    logger.info('Recording tank readings at %s', timezone.now())
    tanks = Tank.objects.prefetch_related('readings').select_related('motor_state').all()
    created_readings = []

    with transaction.atomic():
        for tank in tanks:
            try:
                motor_state = tank.motor_state
            except MotorState.DoesNotExist:
                logger.warning('No MotorState for tank %s — skipping', tank.label)
                continue

            sim = _simulate_reading(tank, motor_state)
            reading = TankReading(
                tank=tank,
                water_level_pct=sim['water_level_pct'],
                purity_index=sim['purity_index'],
                temperature_celsius=sim['temperature_celsius'],
                flow_rate_lpm=sim['flow_rate_lpm'],
                motor_on=sim['motor_on'],
            )
            # water_level_liters computed in save()
            reading.save()
            created_readings.append(reading)
            logger.debug('Reading saved for %s: %.2f%%', tank.label, sim['water_level_pct'])

    # Run automation after recording
    run_automation_logic.delay()

    # Broadcast live update over WebSocket
    _broadcast_tank_update()

    logger.info('Recorded %d tank readings', len(created_readings))
    return len(created_readings)


@shared_task(name='tasks.tank_tasks.run_automation_logic', bind=True)
def run_automation_logic(self):
    """Check thresholds and auto-control motors/pumps. Create alerts as needed."""
    from apps.tanks.models import Tank, MotorState
    from apps.alerts.models import Alert

    tanks = Tank.objects.select_related('motor_state').prefetch_related('readings').all()

    for tank in tanks:
        reading = tank.readings.order_by('-timestamp').first()
        if not reading:
            continue

        try:
            ms = tank.motor_state
        except MotorState.DoesNotExist:
            continue

        level_pct = float(reading.water_level_pct)
        changed = False

        # ── Underground tanks ────────────────────────────────────────────────
        if tank.is_underground and ms.mode == MotorState.Mode.AUTO:
            if level_pct <= float(ms.auto_on_threshold_pct) and not ms.motor_on:
                ms.set_motor(True)
                changed = True
                Alert.create_alert(
                    tank=tank,
                    alert_type=Alert.AlertType.PUMP_AUTO_START,
                    message=(
                        f'Motor auto-started for {tank.label}: '
                        f'level at {level_pct:.1f}% (threshold: {ms.auto_on_threshold_pct}%)'
                    ),
                    severity=Alert.Severity.INFO,
                )
                logger.info('Auto-ON: %s at %.1f%%', tank.label, level_pct)

            elif level_pct >= float(ms.auto_off_threshold_pct) and ms.motor_on:
                ms.set_motor(False)
                changed = True
                logger.info('Auto-OFF: %s at %.1f%%', tank.label, level_pct)

        # ── Terrace tanks (always auto) ──────────────────────────────────────
        elif tank.is_terrace:
            if level_pct <= float(ms.auto_on_threshold_pct) and not ms.motor_on:
                ms.set_motor(True)
                changed = True
                # Also try to ensure linked UG tank's motor is on
                if tank.linked_ug_tank:
                    try:
                        ug_ms = tank.linked_ug_tank.motor_state
                        if not ug_ms.motor_on and ug_ms.mode == MotorState.Mode.AUTO:
                            ug_ms.set_motor(True)
                    except MotorState.DoesNotExist:
                        pass
                logger.info('TR pump auto-ON: %s at %.1f%%', tank.label, level_pct)

            elif level_pct >= float(ms.auto_off_threshold_pct) and ms.motor_on:
                ms.set_motor(False)
                changed = True
                logger.info('TR pump auto-OFF: %s at %.1f%%', tank.label, level_pct)

        # ── Alert: low level (≤ 20%) ─────────────────────────────────────────
        if level_pct <= 20.0:
            Alert.create_alert(
                tank=tank,
                alert_type=Alert.AlertType.LOW_LEVEL,
                message=f'{tank.label} water level critically low: {level_pct:.1f}%',
                severity=Alert.Severity.CRITICAL,
            )

        # ── Alert: poor purity ───────────────────────────────────────────────
        if reading.purity_index == 3:  # Poor
            Alert.create_alert(
                tank=tank,
                alert_type=Alert.AlertType.PURITY_POOR,
                message=f'{tank.label} water purity is POOR — maintenance required.',
                severity=Alert.Severity.WARNING,
            )

    logger.info('Automation logic complete')


@shared_task(name='tasks.tank_tasks.cleanup_old_readings', bind=True)
def cleanup_old_readings(self):
    """Delete TankReadings older than 90 days."""
    from apps.tanks.models import TankReading
    from django.utils import timezone
    import datetime

    cutoff = timezone.now() - datetime.timedelta(days=90)
    deleted, _ = TankReading.objects.filter(timestamp__lt=cutoff).delete()
    logger.info('Cleaned up %d old tank readings (older than 90 days)', deleted)
    return deleted


def _broadcast_tank_update():
    """Push latest tank data + summary to the WebSocket group."""
    from apps.tanks.models import Tank
    from django.utils import timezone

    channel_layer = get_channel_layer()
    if not channel_layer:
        return

    tanks = Tank.objects.select_related(
        'motor_state', 'linked_ug_tank'
    ).prefetch_related('readings').all()

    tank_data = []
    total_water = 0
    total_capacity = 0
    ug_levels, tr_levels = [], []
    ug_motors_on = tr_pumps_on = ug_low = tr_low = 0

    for tank in tanks:
        reading = tank.readings.order_by('-timestamp').first()
        ms = getattr(tank, 'motor_state', None)
        total_capacity += tank.capacity_liters

        if reading:
            level_pct = float(reading.water_level_pct)
            total_water += reading.water_level_liters
            is_low = reading.is_low
            is_full = reading.is_full
            if tank.is_underground:
                ug_levels.append(level_pct)
                if ms and ms.motor_on:
                    ug_motors_on += 1
                if is_low:
                    ug_low += 1
            else:
                tr_levels.append(level_pct)
                if ms and ms.motor_on:
                    tr_pumps_on += 1
                if is_low:
                    tr_low += 1
        else:
            level_pct = 0
            is_low = False
            is_full = False

        tank_data.append({
            'id': tank.id,
            'label': tank.label,
            'tank_type': tank.tank_type,
            'level_pct': float(reading.water_level_pct) if reading else 0,
            'level_liters': reading.water_level_liters if reading else 0,
            'purity_index': reading.purity_index if reading else 0,
            'temperature_celsius': float(reading.temperature_celsius) if reading else 0,
            'flow_rate_lpm': float(reading.flow_rate_lpm) if reading else 0,
            'motor_on': ms.motor_on if ms else False,
            'motor_mode': ms.mode if ms else 'auto',
            'is_low': is_low,
            'is_full': is_full,
        })

    from apps.alerts.models import Alert
    active_alerts = Alert.objects.filter(is_resolved=False).count()
    ug_avg = round(sum(ug_levels) / len(ug_levels), 2) if ug_levels else 0
    tr_avg = round(sum(tr_levels) / len(tr_levels), 2) if tr_levels else 0

    message = {
        'type': 'tank_update',
        'timestamp': timezone.now().isoformat(),
        'tanks': tank_data,
        'summary': {
            'total_water_liters': total_water,
            'total_capacity_liters': total_capacity,
            'ug_avg_level_pct': ug_avg,
            'tr_avg_level_pct': tr_avg,
            'ug_motors_on': ug_motors_on,
            'tr_pumps_on': tr_pumps_on,
            'ug_low_count': ug_low,
            'tr_low_count': tr_low,
            'active_alerts_count': active_alerts,
            'last_updated': timezone.now().isoformat(),
        },
    }

    async_to_sync(channel_layer.group_send)('tanks_live', {
        'type': 'broadcast_message',
        'message': message,
    })
