from django.urls import re_path
from .consumers import TankLiveConsumer

websocket_urlpatterns = [
    re_path(r'^ws/tanks/live/$', TankLiveConsumer.as_asgi()),
]
