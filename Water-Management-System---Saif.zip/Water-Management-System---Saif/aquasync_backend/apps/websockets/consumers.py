import asyncio
import json
import logging
from datetime import datetime

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.middleware import BaseMiddleware
from django.contrib.auth.models import AnonymousUser
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import AccessToken
from urllib.parse import parse_qs

logger = logging.getLogger(__name__)

WS_GROUP_NAME = 'tanks_live'
BROADCAST_INTERVAL = 5  # seconds


@database_sync_to_async
def get_user_from_token(token_key):
    """Validate a JWT access token and return the associated user."""
    from django.contrib.auth import get_user_model
    User = get_user_model()
    try:
        token = AccessToken(token_key)
        user_id = token['user_id']
        return User.objects.get(id=user_id)
    except (InvalidToken, TokenError, User.DoesNotExist) as e:
        logger.warning('WebSocket JWT auth failed: %s', e)
        return AnonymousUser()


class JWTAuthMiddleware(BaseMiddleware):
    """Authenticate WebSocket connections using a JWT token in query string."""

    async def __call__(self, scope, receive, send):
        query_string = scope.get('query_string', b'').decode()
        params = parse_qs(query_string)
        token_list = params.get('token', [None])
        token_key = token_list[0] if token_list else None

        if token_key:
            scope['user'] = await get_user_from_token(token_key)
        else:
            scope['user'] = AnonymousUser()

        return await super().__call__(scope, receive, send)


def JWTAuthMiddlewareStack(inner):
    """Convenience wrapper around JWTAuthMiddleware."""
    return JWTAuthMiddleware(inner)


class TankLiveConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer that streams live tank data every 5 seconds.
    Connects to group 'tanks_live'.
    URL: ws://host/ws/tanks/live/?token=<access_token>
    """

    async def connect(self):
        user = self.scope.get('user')

        if not user or not user.is_authenticated:
            logger.warning('WebSocket connection rejected — unauthenticated')
            await self.close(code=4001)
            return

        await self.channel_layer.group_add(WS_GROUP_NAME, self.channel_name)
        await self.accept()
        logger.info('WebSocket connected: user=%s channel=%s', user.username, self.channel_name)

        # Start the periodic broadcast loop for this connection
        self._broadcast_task = asyncio.create_task(self._periodic_broadcast())

    async def disconnect(self, close_code):
        # Cancel the periodic task if running
        if hasattr(self, '_broadcast_task') and not self._broadcast_task.done():
            self._broadcast_task.cancel()
            try:
                await self._broadcast_task
            except asyncio.CancelledError:
                pass

        await self.channel_layer.group_discard(WS_GROUP_NAME, self.channel_name)
        logger.info('WebSocket disconnected: code=%s', close_code)

    async def receive(self, text_data=None, bytes_data=None):
        """Handle incoming messages (ping/pong or control commands)."""
        if text_data:
            try:
                data = json.loads(text_data)
                if data.get('type') == 'ping':
                    await self.send(text_data=json.dumps({'type': 'pong'}))
            except json.JSONDecodeError:
                pass

    async def broadcast_message(self, event):
        """Called by channel layer group_send — pushes message to this socket."""
        await self.send(text_data=json.dumps(event['message'], default=str))

    async def alert_event(self, event):
        """Push an immediate alert notification to all connected clients."""
        await self.send(text_data=json.dumps({
            'type': 'alert',
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'alert': event['alert'],
        }, default=str))

    async def _periodic_broadcast(self):
        """Broadcast current tank state every BROADCAST_INTERVAL seconds."""
        while True:
            try:
                await asyncio.sleep(BROADCAST_INTERVAL)
                message = await database_sync_to_async(self._build_tank_update)()
                await self.send(text_data=json.dumps(message, default=str))
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception('Error in periodic broadcast: %s', e)

    def _build_tank_update(self):
        """Build the tank_update payload (runs synchronously in thread pool)."""
        from apps.tanks.models import Tank
        from apps.alerts.models import Alert
        from django.utils import timezone

        tanks = Tank.objects.select_related(
            'motor_state', 'linked_ug_tank'
        ).prefetch_related('readings').all()

        tank_data = []
        total_water = 0
        total_capacity = 0
        ug_levels, tr_levels = [], []
        ug_motors_on = tr_pumps_on = ug_low = tr_low = 0

        for tank in tanks:
            reading = tank.readings.order_by('-timestamp').first()
            ms = getattr(tank, 'motor_state', None)
            total_capacity += tank.capacity_liters

            if reading:
                level_pct = float(reading.water_level_pct)
                total_water += reading.water_level_liters
                is_low = reading.is_low
                is_full = reading.is_full
                if tank.is_underground:
                    ug_levels.append(level_pct)
                    if ms and ms.motor_on:
                        ug_motors_on += 1
                    if is_low:
                        ug_low += 1
                else:
                    tr_levels.append(level_pct)
                    if ms and ms.motor_on:
                        tr_pumps_on += 1
                    if is_low:
                        tr_low += 1
            else:
                level_pct = 0
                is_low = False
                is_full = False

            tank_data.append({
                'id': tank.id,
                'label': tank.label,
                'tank_type': tank.tank_type,
                'level_pct': level_pct,
                'level_liters': reading.water_level_liters if reading else 0,
                'purity_index': reading.purity_index if reading else 0,
                'temperature_celsius': float(reading.temperature_celsius) if reading else 0,
                'flow_rate_lpm': float(reading.flow_rate_lpm) if reading else 0,
                'motor_on': ms.motor_on if ms else False,
                'motor_mode': ms.mode if ms else 'auto',
                'is_low': is_low,
                'is_full': is_full,
            })

        active_alerts = Alert.objects.filter(is_resolved=False).count()
        ug_avg = round(sum(ug_levels) / len(ug_levels), 2) if ug_levels else 0
        tr_avg = round(sum(tr_levels) / len(tr_levels), 2) if tr_levels else 0

        return {
            'type': 'tank_update',
            'timestamp': timezone.now().isoformat(),
            'tanks': tank_data,
            'summary': {
                'total_water_liters': total_water,
                'total_capacity_liters': total_capacity,
                'ug_avg_level_pct': ug_avg,
                'tr_avg_level_pct': tr_avg,
                'ug_motors_on': ug_motors_on,
                'tr_pumps_on': tr_pumps_on,
                'ug_low_count': ug_low,
                'tr_low_count': tr_low,
                'active_alerts_count': active_alerts,
                'last_updated': timezone.now().isoformat(),
            },
        }
