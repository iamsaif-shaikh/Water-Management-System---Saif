from django.contrib import admin
from .models import Alert


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = [
        'tank', 'alert_type', 'severity', 'is_resolved', 'created_at', 'resolved_at'
    ]
    list_filter = ['alert_type', 'severity', 'is_resolved']
    search_fields = ['tank__label', 'message']
    ordering = ['-created_at']
    date_hierarchy = 'created_at'
    readonly_fields = ['created_at', 'resolved_at']
    actions = ['mark_resolved']

    def mark_resolved(self, request, queryset):
        for alert in queryset:
            alert.resolve()
        self.message_user(request, f'{queryset.count()} alerts marked as resolved.')
    mark_resolved.short_description = 'Mark selected alerts as resolved'
