from django.db import models
from django.utils import timezone
from apps.tanks.models import Tank


class Alert(models.Model):
    """System-generated alert for tank events."""

    class AlertType(models.TextChoices):
        LOW_LEVEL = 'low_level', 'Low Level'
        HIGH_LEVEL = 'high_level', 'High Level'
        MOTOR_FAULT = 'motor_fault', 'Motor Fault'
        PURITY_POOR = 'purity_poor', 'Poor Purity'
        PUMP_AUTO_START = 'pump_auto_start', 'Pump Auto Start'

    class Severity(models.TextChoices):
        INFO = 'info', 'Info'
        WARNING = 'warning', 'Warning'
        CRITICAL = 'critical', 'Critical'

    tank = models.ForeignKey(
        Tank, on_delete=models.CASCADE, related_name='alerts', db_index=True
    )
    alert_type = models.CharField(
        max_length=30, choices=AlertType.choices, db_index=True
    )
    message = models.TextField()
    severity = models.CharField(
        max_length=20, choices=Severity.choices, default=Severity.WARNING
    )
    is_resolved = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Alert'
        verbose_name_plural = 'Alerts'
        indexes = [
            models.Index(fields=['is_resolved', '-created_at']),
            models.Index(fields=['tank', 'alert_type', 'is_resolved']),
        ]

    def __str__(self):
        return f'[{self.severity.upper()}] {self.tank.label} — {self.alert_type}'

    def resolve(self):
        """Mark this alert as resolved."""
        if not self.is_resolved:
            self.is_resolved = True
            self.resolved_at = timezone.now()
            self.save(update_fields=['is_resolved', 'resolved_at'])

    @classmethod
    def create_alert(cls, tank, alert_type, message, severity):
        """Create an alert, avoiding duplicates for unresolved same-type alerts."""
        existing = cls.objects.filter(
            tank=tank,
            alert_type=alert_type,
            is_resolved=False,
        ).first()
        if existing:
            return existing, False
        alert = cls.objects.create(
            tank=tank,
            alert_type=alert_type,
            message=message,
            severity=severity,
        )
        return alert, True
