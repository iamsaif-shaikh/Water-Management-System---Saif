import django_filters
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from drf_spectacular.utils import extend_schema, OpenApiParameter
from drf_spectacular.types import OpenApiTypes

from .models import Alert
from .serializers import AlertSerializer


class AlertFilter(django_filters.FilterSet):
    resolved = django_filters.BooleanFilter(field_name='is_resolved')
    severity = django_filters.CharFilter(field_name='severity', lookup_expr='exact')
    tank = django_filters.NumberFilter(field_name='tank_id')
    alert_type = django_filters.CharFilter(field_name='alert_type', lookup_expr='exact')

    class Meta:
        model = Alert
        fields = ['resolved', 'severity', 'tank', 'alert_type']


class AlertViewSet(viewsets.ReadOnlyModelViewSet):
    """List and retrieve alerts."""

    queryset = Alert.objects.select_related('tank').order_by('-created_at')
    serializer_class = AlertSerializer
    permission_classes = [IsAuthenticated]
    filterset_class = AlertFilter
    search_fields = ['message', 'tank__label']
    ordering_fields = ['created_at', 'severity']

    @extend_schema(
        responses=AlertSerializer,
        tags=['alerts'],
        summary='Mark an alert as resolved',
    )
    @action(detail=True, methods=['patch'], url_path='resolve')
    def resolve(self, request, pk=None):
        """Mark an alert as resolved."""
        alert = self.get_object()
        if alert.is_resolved:
            return Response(
                {'detail': 'Alert is already resolved.'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        alert.resolve()
        serializer = self.get_serializer(alert)
        return Response(serializer.data)
