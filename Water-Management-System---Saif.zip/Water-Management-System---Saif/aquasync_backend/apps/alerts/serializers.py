from rest_framework import serializers
from .models import Alert


class AlertSerializer(serializers.ModelSerializer):
    tank_label = serializers.CharField(source='tank.label', read_only=True)
    alert_type_display = serializers.CharField(source='get_alert_type_display', read_only=True)
    severity_display = serializers.CharField(source='get_severity_display', read_only=True)

    class Meta:
        model = Alert
        fields = [
            'id', 'tank', 'tank_label', 'alert_type', 'alert_type_display',
            'message', 'severity', 'severity_display',
            'is_resolved', 'created_at', 'resolved_at',
        ]
        read_only_fields = ['id', 'created_at', 'resolved_at']
