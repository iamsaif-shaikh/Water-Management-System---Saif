from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
import logging

User = get_user_model()
logger = logging.getLogger(__name__)


class Tank(models.Model):
    """Represents a physical water tank in the society."""

    class TankType(models.TextChoices):
        UNDERGROUND = 'underground', 'Underground'
        TERRACE = 'terrace', 'Terrace'

    label = models.CharField(max_length=20, unique=True, db_index=True)
    tank_type = models.CharField(
        max_length=20, choices=TankType.choices, db_index=True
    )
    capacity_liters = models.IntegerField(default=15000)
    linked_ug_tank = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='linked_terrace_tanks',
        limit_choices_to={'tank_type': TankType.UNDERGROUND},
        help_text='For terrace tanks: the underground tank that feeds this tank.',
    )
    location_description = models.CharField(max_length=255, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['label']
        verbose_name = 'Tank'
        verbose_name_plural = 'Tanks'

    def __str__(self):
        return f'{self.label} ({self.get_tank_type_display()})'

    @property
    def is_underground(self):
        return self.tank_type == self.TankType.UNDERGROUND

    @property
    def is_terrace(self):
        return self.tank_type == self.TankType.TERRACE

    def get_latest_reading(self):
        """Return the most recent TankReading for this tank."""
        return self.readings.order_by('-timestamp').first()


class TankReading(models.Model):
    """Time-series sensor data for a tank. Written every 30 seconds by Celery."""

    class PurityIndex(models.IntegerChoices):
        EXCELLENT = 0, 'Excellent'
        GOOD = 1, 'Good'
        FAIR = 2, 'Fair'
        POOR = 3, 'Poor'

    tank = models.ForeignKey(
        Tank, on_delete=models.CASCADE, related_name='readings', db_index=True
    )
    water_level_pct = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    water_level_liters = models.IntegerField()
    purity_index = models.IntegerField(
        choices=PurityIndex.choices, default=PurityIndex.GOOD
    )
    temperature_celsius = models.DecimalField(max_digits=5, decimal_places=2, default=25.0)
    flow_rate_lpm = models.DecimalField(
        max_digits=7,
        decimal_places=2,
        default=0.0,
        help_text='Liters per minute; 0 when motor is off.',
    )
    motor_on = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-timestamp']
        get_latest_by = 'timestamp'
        verbose_name = 'Tank Reading'
        verbose_name_plural = 'Tank Readings'
        indexes = [
            models.Index(fields=['tank', '-timestamp']),
        ]

    def __str__(self):
        return f'{self.tank.label} @ {self.timestamp:%Y-%m-%d %H:%M:%S} — {self.water_level_pct}%'

    def save(self, *args, **kwargs):
        # Auto-compute liters from percentage and tank capacity
        if self.water_level_pct is not None and self.tank_id:
            self.water_level_liters = int(
                float(self.water_level_pct) / 100.0 * self.tank.capacity_liters
            )
        super().save(*args, **kwargs)

    @property
    def is_low(self):
        return float(self.water_level_pct) <= 20.0

    @property
    def is_full(self):
        return float(self.water_level_pct) >= 95.0

    @property
    def purity_label(self):
        return self.get_purity_index_display()


class MotorState(models.Model):
    """Tracks the current motor/pump state for each tank."""

    class Mode(models.TextChoices):
        AUTO = 'auto', 'Auto'
        MANUAL_ON = 'manual_on', 'Manual On'
        MANUAL_OFF = 'manual_off', 'Manual Off'

    tank = models.OneToOneField(
        Tank, on_delete=models.CASCADE, related_name='motor_state'
    )
    motor_on = models.BooleanField(default=False)
    mode = models.CharField(
        max_length=20, choices=Mode.choices, default=Mode.AUTO
    )
    last_changed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='motor_changes',
    )
    last_changed_at = models.DateTimeField(auto_now=True)
    auto_on_threshold_pct = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=30.00,
        help_text='Motor turns ON when level drops to or below this %.',
    )
    auto_off_threshold_pct = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=95.00,
        help_text='Motor turns OFF when level rises to or above this %.',
    )

    class Meta:
        verbose_name = 'Motor State'
        verbose_name_plural = 'Motor States'

    def __str__(self):
        status = 'ON' if self.motor_on else 'OFF'
        return f'{self.tank.label} motor — {status} ({self.mode})'

    def set_motor(self, on: bool, changed_by=None):
        """Toggle motor and persist. Returns True if state changed."""
        if self.motor_on != on:
            self.motor_on = on
            if changed_by:
                self.last_changed_by = changed_by
            self.save(update_fields=['motor_on', 'last_changed_by', 'last_changed_at'])
            logger.info(
                'Motor %s for tank %s (changed_by=%s)',
                'ON' if on else 'OFF',
                self.tank.label,
                changed_by,
            )
            return True
        return False
