from rest_framework import serializers
from django.utils import timezone
from .models import Tank, TankReading, MotorState


class MotorStateSerializer(serializers.ModelSerializer):
    last_changed_by_username = serializers.SerializerMethodField()

    class Meta:
        model = MotorState
        fields = [
            'id', 'tank', 'motor_on', 'mode',
            'last_changed_by', 'last_changed_by_username',
            'last_changed_at',
            'auto_on_threshold_pct', 'auto_off_threshold_pct',
        ]
        read_only_fields = ['id', 'tank', 'last_changed_by', 'last_changed_at']

    def get_last_changed_by_username(self, obj):
        return obj.last_changed_by.username if obj.last_changed_by else None


class MotorStateUpdateSerializer(serializers.Serializer):
    mode = serializers.ChoiceField(choices=MotorState.Mode.choices)

    def validate(self, attrs):
        request = self.context.get('request')
        tank = self.context.get('tank')
        if tank and tank.tank_type != Tank.TankType.UNDERGROUND:
            raise serializers.ValidationError(
                'Motor control is only available for underground tanks.'
            )
        return attrs


class TankReadingSerializer(serializers.ModelSerializer):
    is_low = serializers.BooleanField(read_only=True)
    is_full = serializers.BooleanField(read_only=True)
    purity_label = serializers.CharField(read_only=True)

    class Meta:
        model = TankReading
        fields = [
            'id', 'tank', 'water_level_pct', 'water_level_liters',
            'purity_index', 'purity_label', 'temperature_celsius',
            'flow_rate_lpm', 'motor_on', 'timestamp',
            'is_low', 'is_full',
        ]
        read_only_fields = fields


class TankReadingHourlySerializer(serializers.Serializer):
    """Aggregated hourly averages for the history endpoint."""
    hour = serializers.DateTimeField()
    avg_level_pct = serializers.DecimalField(max_digits=5, decimal_places=2)
    avg_level_liters = serializers.FloatField()
    avg_temperature_celsius = serializers.DecimalField(max_digits=5, decimal_places=2)
    avg_flow_rate_lpm = serializers.DecimalField(max_digits=7, decimal_places=2)
    motor_on_count = serializers.IntegerField()
    reading_count = serializers.IntegerField()


class TankSerializer(serializers.ModelSerializer):
    latest_reading = serializers.SerializerMethodField()
    motor_state = MotorStateSerializer(read_only=True)
    linked_ug_tank_label = serializers.SerializerMethodField()
    is_low = serializers.SerializerMethodField()
    is_full = serializers.SerializerMethodField()

    class Meta:
        model = Tank
        fields = [
            'id', 'label', 'tank_type', 'capacity_liters',
            'linked_ug_tank', 'linked_ug_tank_label',
            'location_description', 'created_at', 'updated_at',
            'latest_reading', 'motor_state',
            'is_low', 'is_full',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def get_latest_reading(self, obj):
        reading = obj.get_latest_reading()
        if reading:
            return TankReadingSerializer(reading).data
        return None

    def get_linked_ug_tank_label(self, obj):
        return obj.linked_ug_tank.label if obj.linked_ug_tank else None

    def get_is_low(self, obj):
        reading = obj.get_latest_reading()
        if reading:
            return reading.is_low
        return False

    def get_is_full(self, obj):
        reading = obj.get_latest_reading()
        if reading:
            return reading.is_full
        return False


class DashboardSummarySerializer(serializers.Serializer):
    total_water_liters = serializers.IntegerField()
    total_capacity_liters = serializers.IntegerField()
    ug_avg_level_pct = serializers.DecimalField(max_digits=5, decimal_places=2)
    tr_avg_level_pct = serializers.DecimalField(max_digits=5, decimal_places=2)
    ug_motors_on = serializers.IntegerField()
    tr_pumps_on = serializers.IntegerField()
    ug_low_count = serializers.IntegerField()
    tr_low_count = serializers.IntegerField()
    active_alerts_count = serializers.IntegerField()
    last_updated = serializers.DateTimeField()
