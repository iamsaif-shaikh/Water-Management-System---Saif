import django_filters
from .models import Tank, TankReading


class TankFilter(django_filters.FilterSet):
    tank_type = django_filters.CharFilter(field_name='tank_type', lookup_expr='exact')

    class Meta:
        model = Tank
        fields = ['tank_type']


class TankReadingFilter(django_filters.FilterSet):
    start = django_filters.DateTimeFilter(field_name='timestamp', lookup_expr='gte')
    end = django_filters.DateTimeFilter(field_name='timestamp', lookup_expr='lte')

    class Meta:
        model = TankReading
        fields = ['tank', 'motor_on', 'start', 'end']
