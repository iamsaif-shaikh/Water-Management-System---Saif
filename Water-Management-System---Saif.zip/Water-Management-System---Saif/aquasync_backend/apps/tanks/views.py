import logging
from datetime import timedelta

from django.db.models import Avg, Count, Q
from django.db.models.functions import TruncHour
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from drf_spectacular.utils import extend_schema, OpenApiParameter
from drf_spectacular.types import OpenApiTypes

from apps.alerts.models import Alert
from .filters import TankFilter
from .models import MotorState, Tank, TankReading
from .serializers import (
    DashboardSummarySerializer,
    MotorStateSerializer,
    MotorStateUpdateSerializer,
    TankReadingHourlySerializer,
    TankReadingSerializer,
    TankSerializer,
)

logger = logging.getLogger(__name__)


class TankViewSet(viewsets.ReadOnlyModelViewSet):
    """List and retrieve tanks, with readings and history actions."""

    queryset = (
        Tank.objects.select_related('linked_ug_tank', 'motor_state')
        .prefetch_related('readings')
        .order_by('label')
    )
    serializer_class = TankSerializer
    permission_classes = [IsAuthenticated]
    filterset_class = TankFilter
    search_fields = ['label', 'location_description']

    @extend_schema(
        parameters=[
            OpenApiParameter('limit', OpenApiTypes.INT, description='Number of readings to return (default 100)'),
        ],
        responses=TankReadingSerializer(many=True),
        tags=['tanks'],
        summary='Get last N tank readings',
    )
    @action(detail=True, methods=['get'], url_path='readings')
    def readings(self, request, pk=None):
        """Return the last N readings for a tank (default 100)."""
        tank = self.get_object()
        limit = int(request.query_params.get('limit', 100))
        qs = TankReading.objects.filter(tank=tank).order_by('-timestamp')[:limit]
        serializer = TankReadingSerializer(qs, many=True)
        return Response(serializer.data)

    @extend_schema(
        parameters=[
            OpenApiParameter('days', OpenApiTypes.INT, description='Number of days of history (default 7)'),
        ],
        responses=TankReadingHourlySerializer(many=True),
        tags=['tanks'],
        summary='Get hourly aggregated history',
    )
    @action(detail=True, methods=['get'], url_path='history')
    def history(self, request, pk=None):
        """Return hourly averaged readings for the past N days."""
        tank = self.get_object()
        days = int(request.query_params.get('days', 7))
        since = timezone.now() - timedelta(days=days)

        qs = (
            TankReading.objects.filter(tank=tank, timestamp__gte=since)
            .annotate(hour=TruncHour('timestamp'))
            .values('hour')
            .annotate(
                avg_level_pct=Avg('water_level_pct'),
                avg_level_liters=Avg('water_level_liters'),
                avg_temperature_celsius=Avg('temperature_celsius'),
                avg_flow_rate_lpm=Avg('flow_rate_lpm'),
                motor_on_count=Count('id', filter=Q(motor_on=True)),
                reading_count=Count('id'),
            )
            .order_by('hour')
        )

        serializer = TankReadingHourlySerializer(qs, many=True)
        return Response(serializer.data)


class MotorControlView(APIView):
    """GET/POST motor state for an underground tank."""

    permission_classes = [IsAuthenticated]

    def get_motor_state(self, tank_id):
        try:
            return MotorState.objects.select_related('tank', 'last_changed_by').get(
                tank_id=tank_id
            )
        except MotorState.DoesNotExist:
            return None

    @extend_schema(
        responses=MotorStateSerializer,
        tags=['tanks'],
        summary='Get current motor state',
    )
    def get(self, request, pk):
        motor = self.get_motor_state(pk)
        if not motor:
            return Response({'detail': 'Motor state not found.'}, status=status.HTTP_404_NOT_FOUND)
        serializer = MotorStateSerializer(motor)
        return Response(serializer.data)

    @extend_schema(
        request=MotorStateUpdateSerializer,
        responses=MotorStateSerializer,
        tags=['tanks'],
        summary='Set motor mode (UG tanks only)',
    )
    def post(self, request, pk):
        motor = self.get_motor_state(pk)
        if not motor:
            return Response({'detail': 'Motor state not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = MotorStateUpdateSerializer(
            data=request.data,
            context={'request': request, 'tank': motor.tank},
        )
        serializer.is_valid(raise_exception=True)

        mode = serializer.validated_data['mode']
        motor.mode = mode
        motor.last_changed_by = request.user

        if mode == MotorState.Mode.MANUAL_ON:
            motor.motor_on = True
        elif mode == MotorState.Mode.MANUAL_OFF:
            motor.motor_on = False
        # AUTO mode: motor state controlled by automation logic

        motor.save()
        logger.info(
            'Motor mode for tank %s set to %s by %s',
            motor.tank.label, mode, request.user.username,
        )

        response_serializer = MotorStateSerializer(motor)
        return Response(response_serializer.data)


class DashboardSummaryView(APIView):
    """Aggregate dashboard statistics across all tanks."""

    permission_classes = [IsAuthenticated]

    @extend_schema(
        responses=DashboardSummarySerializer,
        tags=['dashboard'],
        summary='Get aggregate dashboard statistics',
    )
    def get(self, request):
        tanks = Tank.objects.select_related('motor_state').prefetch_related(
            'readings'
        ).all()

        total_water = 0
        total_capacity = 0
        ug_levels = []
        tr_levels = []
        ug_motors_on = 0
        tr_pumps_on = 0
        ug_low_count = 0
        tr_low_count = 0

        for tank in tanks:
            total_capacity += tank.capacity_liters
            reading = tank.get_latest_reading()
            if reading:
                total_water += reading.water_level_liters
                level_pct = float(reading.water_level_pct)
                if tank.is_underground:
                    ug_levels.append(level_pct)
                    if tank.motor_state and tank.motor_state.motor_on:
                        ug_motors_on += 1
                    if reading.is_low:
                        ug_low_count += 1
                else:
                    tr_levels.append(level_pct)
                    if tank.motor_state and tank.motor_state.motor_on:
                        tr_pumps_on += 1
                    if reading.is_low:
                        tr_low_count += 1

        ug_avg = round(sum(ug_levels) / len(ug_levels), 2) if ug_levels else 0
        tr_avg = round(sum(tr_levels) / len(tr_levels), 2) if tr_levels else 0
        active_alerts = Alert.objects.filter(is_resolved=False).count()

        data = {
            'total_water_liters': total_water,
            'total_capacity_liters': total_capacity,
            'ug_avg_level_pct': ug_avg,
            'tr_avg_level_pct': tr_avg,
            'ug_motors_on': ug_motors_on,
            'tr_pumps_on': tr_pumps_on,
            'ug_low_count': ug_low_count,
            'tr_low_count': tr_low_count,
            'active_alerts_count': active_alerts,
            'last_updated': timezone.now(),
        }

        serializer = DashboardSummarySerializer(data)
        return Response(serializer.data)
