from django.apps import AppConfig


class TanksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.tanks'
    verbose_name = 'Tanks'

    def ready(self):
        pass  # signal handlers would go here
