from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TankViewSet, MotorControlView, DashboardSummaryView

app_name = 'tanks'

router = DefaultRouter()
router.register(r'tanks', TankViewSet, basename='tank')

urlpatterns = [
    path('', include(router.urls)),
    path('tanks/<int:pk>/motor/', MotorControlView.as_view(), name='motor-control'),
    path('dashboard/summary/', DashboardSummaryView.as_view(), name='dashboard-summary'),
]
