from django.contrib import admin
from .models import Tank, TankReading, MotorState


@admin.register(Tank)
class TankAdmin(admin.ModelAdmin):
    list_display = ['label', 'tank_type', 'capacity_liters', 'linked_ug_tank', 'location_description']
    list_filter = ['tank_type']
    search_fields = ['label', 'location_description']
    ordering = ['label']


@admin.register(TankReading)
class TankReadingAdmin(admin.ModelAdmin):
    list_display = [
        'tank', 'water_level_pct', 'water_level_liters', 'purity_index',
        'temperature_celsius', 'flow_rate_lpm', 'motor_on', 'timestamp',
    ]
    list_filter = ['tank', 'motor_on', 'purity_index']
    search_fields = ['tank__label']
    ordering = ['-timestamp']
    date_hierarchy = 'timestamp'
    readonly_fields = ['timestamp', 'water_level_liters']


@admin.register(MotorState)
class MotorStateAdmin(admin.ModelAdmin):
    list_display = [
        'tank', 'motor_on', 'mode', 'last_changed_by',
        'last_changed_at', 'auto_on_threshold_pct', 'auto_off_threshold_pct',
    ]
    list_filter = ['motor_on', 'mode']
    search_fields = ['tank__label']
    readonly_fields = ['last_changed_at']
