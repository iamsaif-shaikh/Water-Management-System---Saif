import os
from celery import Celery
from celery.schedules import crontab
from django.conf import settings

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.development')

app = Celery('aquasync')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)

# ── Beat schedule ────────────────────────────────────────────────────────────
app.conf.beat_schedule = {
    'record-tank-readings-every-30s': {
        'task': 'tasks.tank_tasks.record_tank_readings',
        'schedule': 30.0,  # seconds
    },
    'cleanup-old-readings-daily': {
        'task': 'tasks.tank_tasks.cleanup_old_readings',
        'schedule': crontab(hour=2, minute=0),  # 2:00 AM UTC daily
    },
}

app.conf.timezone = 'UTC'
