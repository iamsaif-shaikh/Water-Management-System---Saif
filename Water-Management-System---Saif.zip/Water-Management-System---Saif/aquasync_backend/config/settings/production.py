from .base import *  # noqa: F401, F403

DEBUG = False

SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# Remove silk from production
INSTALLED_APPS = [app for app in INSTALLED_APPS if app != 'silk']  # noqa: F405
MIDDLEWARE = [m for m in MIDDLEWARE if m != 'silk.middleware.SilkyMiddleware']  # noqa: F405
