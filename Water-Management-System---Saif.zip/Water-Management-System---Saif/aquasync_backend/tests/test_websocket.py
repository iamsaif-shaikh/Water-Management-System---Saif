"""
Tests for WebSocket consumer (TankLiveConsumer).
"""
import json
from decimal import Decimal
from unittest.mock import patch, AsyncMock, MagicMock
from django.test import TestCase, TransactionTestCase
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.tokens import RefreshToken
from channels.testing import WebsocketCommunicator
from channels.layers import get_channel_layer

from apps.tanks.models import Tank, TankReading, MotorState
from apps.websockets.consumers import TankLiveConsumer

User = get_user_model()


def get_access_token(user):
    refresh = RefreshToken.for_user(user)
    return str(refresh.access_token)


class WebSocketConnectionTestCase(TransactionTestCase):
    """Tests for WebSocket connection, authentication, and message format."""

    def setUp(self):
        self.admin = User.objects.create_superuser(
            username='wstest_admin',
            password='testpass123',
            email='wstest@aquasync.local',
        )
        self.token = get_access_token(self.admin)

        # Create a UG tank with motor state and a reading
        self.ug_tank = Tank.objects.create(
            label='UG-1',
            tank_type=Tank.TankType.UNDERGROUND,
            capacity_liters=15000,
        )
        self.ug_motor = MotorState.objects.create(
            tank=self.ug_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
            auto_on_threshold_pct=Decimal('30.00'),
            auto_off_threshold_pct=Decimal('95.00'),
        )
        self.reading = TankReading.objects.create(
            tank=self.ug_tank,
            water_level_pct=Decimal('60.00'),
            water_level_liters=9000,
            purity_index=1,
            temperature_celsius=Decimal('26.0'),
            flow_rate_lpm=Decimal('0.0'),
            motor_on=False,
        )

    async def _get_communicator(self, token=None):
        """Helper to create a WebSocket communicator."""
        from config.asgi import application
        query = f'?token={token}' if token else ''
        communicator = WebsocketCommunicator(
            application,
            f'/ws/tanks/live/{query}',
        )
        return communicator

    async def test_authenticated_connection_accepted(self):
        """A valid JWT token should allow connection."""
        communicator = await self._get_communicator(token=self.token)
        connected, subprotocol = await communicator.connect()
        self.assertTrue(connected, 'WebSocket should accept authenticated connection')
        await communicator.disconnect()

    async def test_unauthenticated_connection_rejected(self):
        """Connection without token should be rejected with code 4001."""
        communicator = await self._get_communicator(token=None)
        connected, code = await communicator.connect()
        self.assertFalse(connected, 'WebSocket should reject unauthenticated connection')
        self.assertEqual(code, 4001)

    async def test_invalid_token_connection_rejected(self):
        """Connection with an invalid JWT token should be rejected."""
        communicator = await self._get_communicator(token='invalid.jwt.token')
        connected, code = await communicator.connect()
        self.assertFalse(connected, 'WebSocket should reject invalid JWT token')
        await communicator.disconnect()

    async def test_ping_pong(self):
        """Connected client should receive pong on ping."""
        communicator = await self._get_communicator(token=self.token)
        connected, _ = await communicator.connect()
        self.assertTrue(connected)

        await communicator.send_json_to({'type': 'ping'})
        response = await communicator.receive_json_from(timeout=5)
        self.assertEqual(response['type'], 'pong')

        await communicator.disconnect()

    async def test_broadcast_message_schema(self):
        """Broadcast message should have required fields with correct types."""
        communicator = await self._get_communicator(token=self.token)
        connected, _ = await communicator.connect()
        self.assertTrue(connected)

        # Wait for the first periodic broadcast (within 10 seconds)
        response = await communicator.receive_json_from(timeout=10)

        # Validate top-level structure
        self.assertEqual(response['type'], 'tank_update')
        self.assertIn('timestamp', response)
        self.assertIn('tanks', response)
        self.assertIn('summary', response)

        # Validate tanks array
        self.assertIsInstance(response['tanks'], list)
        if response['tanks']:
            tank = response['tanks'][0]
            required_tank_fields = [
                'id', 'label', 'tank_type', 'level_pct', 'level_liters',
                'purity_index', 'temperature_celsius', 'flow_rate_lpm',
                'motor_on', 'motor_mode', 'is_low', 'is_full',
            ]
            for field in required_tank_fields:
                self.assertIn(field, tank, f'Tank data missing field: {field}')

        # Validate summary
        summary = response['summary']
        required_summary_fields = [
            'total_water_liters', 'total_capacity_liters',
            'ug_avg_level_pct', 'tr_avg_level_pct',
            'ug_motors_on', 'tr_pumps_on',
            'ug_low_count', 'tr_low_count',
            'active_alerts_count', 'last_updated',
        ]
        for field in required_summary_fields:
            self.assertIn(field, summary, f'Summary missing field: {field}')

        await communicator.disconnect()

    async def test_disconnect_cleans_up(self):
        """Disconnecting should not raise errors."""
        communicator = await self._get_communicator(token=self.token)
        connected, _ = await communicator.connect()
        self.assertTrue(connected)
        await communicator.disconnect()
        # No assertion needed — just verifying no exception is raised


class WebSocketAlertBroadcastTestCase(TransactionTestCase):
    """Tests for immediate alert broadcasts."""

    def setUp(self):
        self.admin = User.objects.create_superuser(
            username='wsalert_admin',
            password='testpass123',
            email='wsalert@aquasync.local',
        )
        self.token = get_access_token(self.admin)
        self.ug_tank = Tank.objects.create(
            label='UG-2',
            tank_type=Tank.TankType.UNDERGROUND,
            capacity_liters=15000,
        )
        MotorState.objects.create(
            tank=self.ug_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
        )

    async def test_alert_broadcast_format(self):
        """alert_event should push a message with type='alert' and alert data."""
        from config.asgi import application
        communicator = WebsocketCommunicator(
            application,
            f'/ws/tanks/live/?token={self.token}',
        )
        connected, _ = await communicator.connect()
        self.assertTrue(connected)

        # Simulate sending an alert event to the group
        channel_layer = get_channel_layer()
        await channel_layer.group_send(
            'tanks_live',
            {
                'type': 'alert_event',
                'alert': {
                    'id': 1,
                    'tank_label': 'UG-2',
                    'alert_type': 'low_level',
                    'message': 'Test low level alert',
                    'severity': 'critical',
                },
            },
        )

        # Skip any tank_update messages until we get the alert
        for _ in range(5):
            response = await communicator.receive_json_from(timeout=10)
            if response.get('type') == 'alert':
                break
        else:
            self.fail('Did not receive an alert message within timeout')

        self.assertEqual(response['type'], 'alert')
        self.assertIn('timestamp', response)
        self.assertIn('alert', response)
        alert = response['alert']
        self.assertEqual(alert['alert_type'], 'low_level')
        self.assertEqual(alert['severity'], 'critical')

        await communicator.disconnect()

