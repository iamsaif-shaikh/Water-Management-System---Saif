"""
Tests for Celery automation logic.
"""
from decimal import Decimal
from unittest.mock import patch, MagicMock
from django.test import TestCase
from django.contrib.auth import get_user_model

from apps.tanks.models import Tank, TankReading, MotorState
from apps.alerts.models import Alert

User = get_user_model()


class AutomationLogicTestCase(TestCase):
    """Unit tests for run_automation_logic task."""

    def setUp(self):
        # UG tank
        self.ug_tank = Tank.objects.create(
            label='UG-1',
            tank_type=Tank.TankType.UNDERGROUND,
            capacity_liters=15000,
        )
        self.ug_motor = MotorState.objects.create(
            tank=self.ug_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
            auto_on_threshold_pct=Decimal('30.00'),
            auto_off_threshold_pct=Decimal('95.00'),
        )

        # TR tank linked to UG-1
        self.tr_tank = Tank.objects.create(
            label='TR-01',
            tank_type=Tank.TankType.TERRACE,
            capacity_liters=15000,
            linked_ug_tank=self.ug_tank,
        )
        self.tr_motor = MotorState.objects.create(
            tank=self.tr_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
            auto_on_threshold_pct=Decimal('25.00'),
            auto_off_threshold_pct=Decimal('92.00'),
        )

    def _create_reading(self, tank, level_pct, purity_index=1, motor_on=False):
        reading = TankReading(
            tank=tank,
            water_level_pct=Decimal(str(level_pct)),
            purity_index=purity_index,
            temperature_celsius=Decimal('26.0'),
            flow_rate_lpm=Decimal('0.0'),
            motor_on=motor_on,
        )
        reading.save()
        return reading

    # ── UG auto-on tests ──────────────────────────────────────────────────

    def test_ug_auto_motor_on_at_threshold(self):
        """UG motor should auto-start when level <= auto_on_threshold."""
        self._create_reading(self.ug_tank, level_pct=28.0)  # below 30%

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()  # run synchronously

        self.ug_motor.refresh_from_db()
        self.assertTrue(self.ug_motor.motor_on, 'Motor should be ON below threshold')

    def test_ug_auto_motor_on_creates_pump_auto_start_alert(self):
        """Auto-starting motor should create a pump_auto_start alert."""
        self._create_reading(self.ug_tank, level_pct=25.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        alert = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.PUMP_AUTO_START,
            is_resolved=False,
        ).first()
        self.assertIsNotNone(alert, 'pump_auto_start alert should be created')

    def test_ug_motor_not_started_when_above_threshold(self):
        """UG motor should NOT auto-start when level is above threshold."""
        self._create_reading(self.ug_tank, level_pct=55.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.ug_motor.refresh_from_db()
        self.assertFalse(self.ug_motor.motor_on)

    # ── UG auto-off tests ─────────────────────────────────────────────────

    def test_ug_auto_motor_off_at_threshold(self):
        """UG motor should auto-stop when level >= auto_off_threshold."""
        self.ug_motor.motor_on = True
        self.ug_motor.save()
        self._create_reading(self.ug_tank, level_pct=96.0, motor_on=True)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.ug_motor.refresh_from_db()
        self.assertFalse(self.ug_motor.motor_on, 'Motor should be OFF above off-threshold')

    def test_ug_motor_stays_on_between_thresholds(self):
        """Motor should stay on when level is between thresholds."""
        self.ug_motor.motor_on = True
        self.ug_motor.save()
        self._create_reading(self.ug_tank, level_pct=60.0, motor_on=True)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.ug_motor.refresh_from_db()
        self.assertTrue(self.ug_motor.motor_on)

    # ── Manual mode tests ─────────────────────────────────────────────────

    def test_manual_mode_ignores_automation(self):
        """Motor in manual_off mode should NOT be auto-started even if below threshold."""
        self.ug_motor.mode = MotorState.Mode.MANUAL_OFF
        self.ug_motor.save()
        self._create_reading(self.ug_tank, level_pct=10.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.ug_motor.refresh_from_db()
        self.assertFalse(self.ug_motor.motor_on, 'Manual mode should prevent auto-start')

    # ── Terrace auto tests ────────────────────────────────────────────────

    def test_tr_pump_auto_on_at_threshold(self):
        """TR pump should auto-start when level <= TR auto_on_threshold."""
        self._create_reading(self.tr_tank, level_pct=20.0)  # below 25%

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.tr_motor.refresh_from_db()
        self.assertTrue(self.tr_motor.motor_on, 'TR pump should be ON below threshold')

    def test_tr_pump_auto_off_at_threshold(self):
        """TR pump should auto-stop when level >= TR auto_off_threshold."""
        self.tr_motor.motor_on = True
        self.tr_motor.save()
        self._create_reading(self.tr_tank, level_pct=93.0, motor_on=True)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        self.tr_motor.refresh_from_db()
        self.assertFalse(self.tr_motor.motor_on, 'TR pump should be OFF above off-threshold')

    # ── Alert tests ───────────────────────────────────────────────────────

    def test_low_level_alert_at_20_percent(self):
        """A low_level alert should be created when level <= 20%."""
        self._create_reading(self.ug_tank, level_pct=15.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        alert = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.LOW_LEVEL,
            is_resolved=False,
        ).first()
        self.assertIsNotNone(alert)
        self.assertEqual(alert.severity, Alert.Severity.CRITICAL)

    def test_no_low_level_alert_above_20_percent(self):
        """No low_level alert should be created when level > 20%."""
        self._create_reading(self.ug_tank, level_pct=50.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        alert = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.LOW_LEVEL,
        ).first()
        self.assertIsNone(alert)

    def test_purity_poor_alert_created(self):
        """A purity_poor alert should be created when purity_index == 3 (Poor)."""
        self._create_reading(self.ug_tank, level_pct=50.0, purity_index=3)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        alert = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.PURITY_POOR,
            is_resolved=False,
        ).first()
        self.assertIsNotNone(alert)
        self.assertEqual(alert.severity, Alert.Severity.WARNING)

    def test_no_purity_alert_for_good_purity(self):
        """No purity_poor alert when purity_index is 0, 1, or 2."""
        self._create_reading(self.ug_tank, level_pct=50.0, purity_index=1)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()

        alert = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.PURITY_POOR,
        ).first()
        self.assertIsNone(alert)

    def test_duplicate_alerts_not_created(self):
        """create_alert should not create a duplicate for an unresolved alert."""
        self._create_reading(self.ug_tank, level_pct=15.0)

        from tasks.tank_tasks import run_automation_logic
        run_automation_logic.apply()
        run_automation_logic.apply()  # run twice

        count = Alert.objects.filter(
            tank=self.ug_tank,
            alert_type=Alert.AlertType.LOW_LEVEL,
            is_resolved=False,
        ).count()
        self.assertEqual(count, 1, 'Duplicate unresolved alerts should not be created')


class CleanupReadingsTestCase(TestCase):
    """Tests for cleanup_old_readings task."""

    def test_old_readings_are_deleted(self):
        """Readings older than 90 days should be deleted."""
        import datetime
        from django.utils import timezone

        tank = Tank.objects.create(
            label='UG-TEST',
            tank_type=Tank.TankType.UNDERGROUND,
            capacity_liters=15000,
        )
        MotorState.objects.create(tank=tank)

        # Create an old reading (91 days ago)
        old_reading = TankReading.objects.create(
            tank=tank,
            water_level_pct=Decimal('50.00'),
            water_level_liters=7500,
            purity_index=1,
            temperature_celsius=Decimal('26.0'),
            flow_rate_lpm=Decimal('0.0'),
            motor_on=False,
        )
        # Manually set timestamp to 91 days ago
        old_date = timezone.now() - datetime.timedelta(days=91)
        TankReading.objects.filter(id=old_reading.id).update(timestamp=old_date)

        # Create a recent reading
        TankReading.objects.create(
            tank=tank,
            water_level_pct=Decimal('50.00'),
            water_level_liters=7500,
            purity_index=1,
            temperature_celsius=Decimal('26.0'),
            flow_rate_lpm=Decimal('0.0'),
            motor_on=False,
        )

        from tasks.tank_tasks import cleanup_old_readings
        deleted_count = cleanup_old_readings.apply().result

        self.assertEqual(deleted_count, 1)
        self.assertEqual(TankReading.objects.filter(tank=tank).count(), 1)

