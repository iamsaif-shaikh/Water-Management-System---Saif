"""
Tests for motor control API endpoint.
"""
from decimal import Decimal
from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework_simplejwt.tokens import RefreshToken

from apps.tanks.models import Tank, MotorState
from apps.alerts.models import Alert

User = get_user_model()


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return str(refresh.access_token)


class MotorControlTestCase(APITestCase):
    """Tests for GET/POST /api/tanks/{id}/motor/"""

    def setUp(self):
        self.admin = User.objects.create_superuser(
            username='testadmin', password='testpass123', email='test@aquasync.local'
        )
        self.token = get_tokens_for_user(self.admin)
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {self.token}')

        # Create an UG tank
        self.ug_tank = Tank.objects.create(
            label='UG-1',
            tank_type=Tank.TankType.UNDERGROUND,
            capacity_liters=15000,
        )
        self.ug_motor = MotorState.objects.create(
            tank=self.ug_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
            auto_on_threshold_pct=Decimal('30.00'),
            auto_off_threshold_pct=Decimal('95.00'),
        )

        # Create a TR tank
        self.tr_tank = Tank.objects.create(
            label='TR-01',
            tank_type=Tank.TankType.TERRACE,
            capacity_liters=15000,
            linked_ug_tank=self.ug_tank,
        )
        self.tr_motor = MotorState.objects.create(
            tank=self.tr_tank,
            motor_on=False,
            mode=MotorState.Mode.AUTO,
            auto_on_threshold_pct=Decimal('25.00'),
            auto_off_threshold_pct=Decimal('92.00'),
        )

    def _motor_url(self, tank_id):
        return reverse('tanks:motor-control', kwargs={'pk': tank_id})

    # ── Auth tests ──────────────────────────────────────────────────────────

    def test_requires_authentication(self):
        """Motor control endpoint must reject unauthenticated requests."""
        self.client.credentials()  # remove token
        url = self._motor_url(self.ug_tank.id)
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    # ── GET tests ────────────────────────────────────────────────────────────

    def test_get_motor_state_returns_200(self):
        """GET motor state for a valid tank returns 200."""
        url = self._motor_url(self.ug_tank.id)
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('motor_on', response.data)
        self.assertIn('mode', response.data)

    def test_get_motor_state_initial_values(self):
        """Initial motor state should be off and in auto mode."""
        url = self._motor_url(self.ug_tank.id)
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(response.data['motor_on'])
        self.assertEqual(response.data['mode'], 'auto')

    # ── Mode switching tests ──────────────────────────────────────────────

    def test_set_mode_manual_on(self):
        """Setting mode to manual_on should turn motor on."""
        url = self._motor_url(self.ug_tank.id)
        response = self.client.post(url, {'mode': 'manual_on'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['mode'], 'manual_on')
        self.assertTrue(response.data['motor_on'])

        # Verify DB state
        self.ug_motor.refresh_from_db()
        self.assertTrue(self.ug_motor.motor_on)
        self.assertEqual(self.ug_motor.mode, MotorState.Mode.MANUAL_ON)

    def test_set_mode_manual_off(self):
        """Setting mode to manual_off should turn motor off."""
        # First turn it on
        self.ug_motor.motor_on = True
        self.ug_motor.save()

        url = self._motor_url(self.ug_tank.id)
        response = self.client.post(url, {'mode': 'manual_off'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['mode'], 'manual_off')
        self.assertFalse(response.data['motor_on'])

        self.ug_motor.refresh_from_db()
        self.assertFalse(self.ug_motor.motor_on)

    def test_set_mode_auto(self):
        """Setting mode to auto is valid and persists."""
        url = self._motor_url(self.ug_tank.id)
        response = self.client.post(url, {'mode': 'auto'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['mode'], 'auto')

    def test_invalid_mode_returns_400(self):
        """An invalid mode string should return 400."""
        url = self._motor_url(self.ug_tank.id)
        response = self.client.post(url, {'mode': 'invalid_mode'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_set_mode_records_changed_by(self):
        """Motor state change should record the user who changed it."""
        url = self._motor_url(self.ug_tank.id)
        self.client.post(url, {'mode': 'manual_on'}, format='json')
        self.ug_motor.refresh_from_db()
        self.assertEqual(self.ug_motor.last_changed_by, self.admin)

    # ── UG-only restriction tests ─────────────────────────────────────────

    def test_terrace_tank_motor_control_rejected(self):
        """Motor control POST on a terrace tank should return 400 (validation error)."""
        url = self._motor_url(self.tr_tank.id)
        response = self.client.post(url, {'mode': 'manual_on'}, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('non_field_errors', response.data)

    def test_terrace_tank_motor_get_allowed(self):
        """GET motor state for a terrace tank should still return 200."""
        url = self._motor_url(self.tr_tank.id)
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_nonexistent_tank_returns_404(self):
        """Motor control on a non-existent tank ID should return 404."""
        url = self._motor_url(9999)
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

